#include <stdio.h>

typedef struct {
char titre[100];
char auteur[100];
int numid;
char categorie[100];
int date;
}book;

void Borrowbook(Borrow** premier,book *li){
	Borrow B, q*;
	q=*premier
		
}
