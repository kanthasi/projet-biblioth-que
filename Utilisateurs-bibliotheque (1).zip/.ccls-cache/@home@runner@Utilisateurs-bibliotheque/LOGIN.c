#include <stdio.h>
#include <string.h>
#include <stdlib.h>


struct login{
char nomutilisateur[20];
char motdepasse[20];
};

void registre()
{
	FILE *log;
	log=fopen("loginprojet.txt","w");
	struct login l;
	printf("entre nom utilisateur :");
	scanf("%s",l.nomutilisateur);
	printf("entre un mot de passe :");
	scanf("%s",l.motdepasse);
	fwrite(&l,sizeof(1),1,log);
	fclose(log);
	printf("\n nom utilsateur : \n");
	printf(" login avec ton mdp");
	return;
}

/*void login()
{
	char nomutilisateur[20],motdepasse[20];
	FILE *log;
	log=fopen("loginprojet.txt","r");
	struct login l;
	printf("nom d'utilisateur : ");
	scanf("%s",&nomutilisateur);
	 printf("mot de passe :");
	 scanf("%s",&motdepasse);
	
}*/