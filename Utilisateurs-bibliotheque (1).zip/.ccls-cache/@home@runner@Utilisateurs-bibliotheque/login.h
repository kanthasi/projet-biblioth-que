
#include "struct.h"

void reg();
void login();
void getch();
void EmprunterLivre(Emprunt **premier,book *Li,user *user);
void Emprunteur_0u_Non(Emprunt **Emp);

